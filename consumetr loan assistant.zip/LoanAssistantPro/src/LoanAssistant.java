
import java.awt.Color;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;



public class LoanAssistant extends javax.swing.JFrame {

    private boolean computPayment;
    private Object computePayment;
    double loan;
    double interest;
    double month;
    double payment;
    double MonthlyPayment;

    
    public LoanAssistant() {
        initComponents();
        
     
        XmonthButton.doClick();
        newLoanButton.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField4 = new javax.swing.JTextField();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        computButton = new javax.swing.JButton();
        newLoanButton = new javax.swing.JButton();
        intersetField = new javax.swing.JTextField();
        balanceField = new javax.swing.JTextField();
        monthField = new javax.swing.JTextField();
        paymentField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        analysisTextAria = new javax.swing.JTextArea();
        XmonthButton = new javax.swing.JButton();
        XpaymentButton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Loan Assistant");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("Loan Balance:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Interest Rate: ");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("Number of Payment:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Monthly Payment:");

        computButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        computButton.setText("Compute Monthly Payment");
        computButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                computButtonActionPerformed(evt);
            }
        });

        newLoanButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        newLoanButton.setText("New Loan Analysis");
        newLoanButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newLoanButtonActionPerformed(evt);
            }
        });

        intersetField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        balanceField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        monthField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        paymentField.setBackground(new java.awt.Color(255, 255, 153));
        paymentField.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        analysisTextAria.setColumns(20);
        analysisTextAria.setRows(5);
        jScrollPane1.setViewportView(analysisTextAria);

        XmonthButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        XmonthButton.setText("X");
        XmonthButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XmonthButtonActionPerformed(evt);
            }
        });

        XpaymentButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        XpaymentButton.setText("X");
        XpaymentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XpaymentButtonActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("Loan Analysis");

        exitButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(133, 133, 133)
                .addComponent(newLoanButton, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(47, 47, 47)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(paymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(monthField, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(102, 102, 102)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(balanceField, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(intersetField))))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(XmonthButton, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(XpaymentButton, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(109, 109, 109)
                        .addComponent(computButton, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(balanceField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(intersetField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(paymentField, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(XpaymentButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(monthField, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(XmonthButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addComponent(computButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(15, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(newLoanButton, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(exitButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void newLoanButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newLoanButtonActionPerformed
  
        
        balanceField.setText("");
        intersetField.setText("");
        paymentField.setText("");
        analysisTextAria.setText("");
        newLoanButton.setEnabled(false);
       computButton.setEnabled(true);
    }//GEN-LAST:event_newLoanButtonActionPerformed

    private void XpaymentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XpaymentButtonActionPerformed
       computePayment=true;
       XpaymentButton.setVisible(false);
       XmonthButton.setVisible(true);
       monthField.setEditable(true);
       monthField.setBackground(Color.WHITE);
       monthField.setFocusable(true);
       paymentField.setEditable(false);
       paymentField.setBackground(Color.YELLOW);
      paymentField.setFocusable(false);
      balanceField.requestFocus();
       
    }//GEN-LAST:event_XpaymentButtonActionPerformed

    private void XmonthButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XmonthButtonActionPerformed
      computePayment = false;
      XpaymentButton.setVisible(true);
      XmonthButton.setVisible(false);
      monthField.setEditable(false);
      monthField.setBackground(Color.YELLOW);
      monthField.setFocusable(false);
      paymentField.setEditable(true);
      paymentField.setBackground(Color.WHITE);
      paymentField.setFocusable(true);
      balanceField.requestFocus();
      computButton.setVisible(true);
     
    }//GEN-LAST:event_XmonthButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void computButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_computButtonActionPerformed
       
        
        String iMonthPayment = String.format(monthField.getText());
        
        if(balanceField.getText().equals("")){
            JOptionPane.showMessageDialog(null,"You must enter amoun of Balance",
                    "Loan System",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            loan = Double.parseDouble(balanceField.getText());
            String Balance = String.format(balanceField.getText());
        }
        if(intersetField.getText().equals("")){
            JOptionPane.showMessageDialog(null,"You must enter amoun of Interest Rate",
                    "Loan System",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            interest = Double.parseDouble(intersetField.getText());
            String iInterest = String.format(intersetField.getText());
        }
           
        if(paymentField.getText().equals("")){
            JOptionPane.showMessageDialog(null,"You must enter amoun of Number of Payment",
                    "Loan System",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            month = Double.parseDouble(paymentField.getText());
            String iMonth = String.format(paymentField.getText());
        }
         
        payment = loan + ((loan * interest)/100);
        
        MonthlyPayment = payment / month;
        String PayMonth = String.format("%.2f",MonthlyPayment);
        monthField.setText(PayMonth);
        analysisTextAria.append("\t\n Loan Assistan Project:\n\n"+
                                "Amoun of Loan:\t\t $"+ loan +
                                "\n Number of Payment:\t\t $"+ interest+
                                "\nMonthly Payment:\t\t $" + month+ 
                                 "\nPayment Per Month:\t\t $" +MonthlyPayment+ 
                                 "\nTotal Loan Payment:\t\t $" +payment+ 
                                  "\n\nThanks for using loan System");
        newLoanButton.setEnabled(true);
       computButton.setEnabled(false);
    }//GEN-LAST:event_computButtonActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoanAssistant().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton XmonthButton;
    private javax.swing.JButton XpaymentButton;
    private javax.swing.JTextArea analysisTextAria;
    private javax.swing.JTextField balanceField;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton computButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JTextField intersetField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField monthField;
    private javax.swing.JButton newLoanButton;
    private javax.swing.JTextField paymentField;
    // End of variables declaration//GEN-END:variables
}
